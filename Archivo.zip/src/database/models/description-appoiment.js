const {DataTypes, Model} = require('sequelize')
const sequelize = require('../db')

class DescriptionAppoiment extends Model{}

DescriptionAppoiment.init({
  id_descripcion_appoiment: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  id_service: DataTypes.INTEGER,
  minutes_service: DataTypes.INTEGER,
  price_service: DataTypes.INTEGER,
  porcentage: DataTypes.INTEGER,
  id_appoiment: DataTypes.INTEGER,
},{
  sequelize,
  modelName: 'description-appoiment'
})

module.exports = DescriptionAppoiment