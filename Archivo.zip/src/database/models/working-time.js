const {DataTypes, Model} = require('sequelize')
const sequelize = require('../db')

class WorkingTime extends Model{}

WorkingTime.init({
  id_working_time: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  id_admin: DataTypes.INTEGER,
  start_time: DataTypes.TIME,
  end_time: DataTypes.TIME,
  day: DataTypes.INTEGER(1),
  state: DataTypes.INTEGER(1)
},{
  sequelize,
  modelName: 'working-time'
})

module.exports = WorkingTime