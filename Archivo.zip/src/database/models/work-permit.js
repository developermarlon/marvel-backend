const {DataTypes, Model} = require('sequelize')
const sequelize = require('../db')

class WorkPermit extends Model{}

WorkPermit.init({
  id_work_permit: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  id_admin: DataTypes.INTEGER,
  start_date: DataTypes.DATE,
  end_date: DataTypes.DATE,
  observation: DataTypes.TEXT,
  state: DataTypes.INTEGER(1)
},{
  sequelize,
  modelName: 'work-permit'
})

module.exports = WorkPermit