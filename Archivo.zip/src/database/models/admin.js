const {Model, DataTypes} = require('sequelize')
const sequelize = require ('../db')

class Admin extends Model{}

Admin.init({
    id_admin: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    }, 
    name: DataTypes.STRING(50),
    last_name: DataTypes.STRING(50),
    email: DataTypes.STRING(50),
    phone: DataTypes.STRING(50),
    password: DataTypes.STRING(100),
    state: DataTypes.INTEGER,
    photo: DataTypes.STRING(150),
    last_ip_login: DataTypes.STRING(20),
    device_type: DataTypes.STRING(50),
    device_brand: DataTypes.STRING(50),
    device_model: DataTypes.STRING(50),
    client_name: DataTypes.STRING(50),
    os_name: DataTypes.STRING(50),
    os_version: DataTypes.STRING(50),
    lat: DataTypes.FLOAT,
    lng: DataTypes.FLOAT,
    region: DataTypes.STRING(80)
},{
    sequelize,
    modelName: 'admin'
})

module.exports = Admin