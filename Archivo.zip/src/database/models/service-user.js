const {DataTypes, Model} = require('sequelize')
const sequelize = require('../db')

class ServiceUser extends Model{}

ServiceUser.init({
  id_service_user: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  id_admin: DataTypes.INTEGER,
  id_service: DataTypes.INTEGER,
  observation: DataTypes.TEXT,
  porcentage: DataTypes.INTEGER,
  state: DataTypes.INTEGER(1)
},{
  sequelize,
  modelName: 'service-user'
})

module.exports = ServiceUser