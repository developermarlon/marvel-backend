const {DataTypes, Model} = require('sequelize')
const sequelize = require('../db')

class WebPush extends Model{}

WebPush.init({
  id_web_push: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  ip: DataTypes.STRING(20),
  subscription: DataTypes.JSON,
  state: DataTypes.INTEGER(1),
  device_type: DataTypes.STRING(50),
  device_brand: DataTypes.STRING(50),
  device_model: DataTypes.STRING(50),
  client_name: DataTypes.STRING(50),
  os_name: DataTypes.STRING(50),
  os_version: DataTypes.STRING(50)
},{
  sequelize,
  modelName: 'web-push'
})

module.exports = WebPush