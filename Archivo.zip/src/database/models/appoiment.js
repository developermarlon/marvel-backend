const {DataTypes, Model} = require('sequelize')
const sequelize = require('../db')

class Appoiment extends Model{}

Appoiment.init({
  id_appoiment: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  id_admin_service: DataTypes.INTEGER,

  id_user: DataTypes.INTEGER,
  date_appoiment: DataTypes.DATE,
  date_end_appoiment: DataTypes.DATE,
  state: DataTypes.INTEGER(1),
  date_notification: DataTypes.DATE,
  state_notification: DataTypes.INTEGER(1),
  message_confirm_apoiment: DataTypes.TEXT,
  minutes_before_notification: DataTypes.INTEGER,
  money_received: DataTypes.INTEGER,
  change: DataTypes.INTEGER,
  service_price: DataTypes.INTEGER,
  id_admin_update: DataTypes.INTEGER,
  date_admin_update: DataTypes.DATE,
  date_user_update: DataTypes.DATE,
  observation_user: DataTypes.TEXT,
  observation_admin: DataTypes.TEXT,
  value_stars: DataTypes.INTEGER(1),
  ip: DataTypes.STRING(20),
  device_type: DataTypes.STRING(50),
  device_brand: DataTypes.STRING(50),
  device_model: DataTypes.STRING(50),
  client_name: DataTypes.STRING(50),
  os_name: DataTypes.STRING(50),
  os_version: DataTypes.STRING(50),
  lat: DataTypes.FLOAT,
  lng: DataTypes.FLOAT,
  region: DataTypes.STRING(80)
},{
  sequelize,
  modelName: 'appoiment'
})

module.exports = Appoiment