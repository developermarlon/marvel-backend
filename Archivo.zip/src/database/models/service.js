const {DataTypes, Model} = require('sequelize')
const sequelize = require('../db')

class Service extends Model{}

Service.init({
  id_service: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: DataTypes.STRING(30),
  photo: DataTypes.STRING(150),
  price: DataTypes.INTEGER,
  minutes: DataTypes.INTEGER,
  description: DataTypes.TEXT,
  state: DataTypes.INTEGER(1)
},{
  sequelize,
  modelName: 'service'
})

module.exports = Service