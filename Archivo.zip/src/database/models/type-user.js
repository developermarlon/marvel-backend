const {Model, DataTypes} = require('sequelize')
const sequelize = require ('../db')

class TypeUser extends Model{}

TypeUser.init({
    id_type: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    }, 
    name: DataTypes.STRING(50),
    state: DataTypes.INTEGER
},{
    sequelize,
    modelName: 'types_user'
})

module.exports = TypeUser