const Admin = require('./models/admin')
const User = require('./models/user')
const TypeUser = require('./models/type-user')
const WorkingTime = require('./models/working-time')
const WorkPermit = require('./models/work-permit')
const Service = require('./models/service')
const ServiceUser = require('./models/service-user')

const Appoiment = require('./models/appoiment')
const DescriptionAppoiment = require('./models/description-appoiment')

//MODEL admin
Admin.belongsTo(TypeUser, {foreignKey: 'type_user'})
Admin.hasMany(WorkingTime, {foreignKey: 'id_admin'})
Admin.hasMany(WorkPermit, {foreignKey: 'id_admin'})
Admin.hasMany(ServiceUser, {foreignKey: 'id_admin'})
Admin.hasMany(Appoiment, {foreignKey: 'id_admin_service'})

//MODEL TypeUser
TypeUser.hasOne(Admin, {foreignKey: 'type_user'})

//MODEL WorkingTime
WorkingTime.belongsTo(Admin, {foreignKey: 'id_admin'})

//MODEL WorkPermit
WorkPermit.belongsTo(Admin, {foreignKey: 'id_admin'})

//MODEL Service
Service.hasMany(ServiceUser, {foreignKey: 'id_service'})
Service.hasMany(DescriptionAppoiment, {foreignKey: 'id_service'})

//MODEL ServiceUser
ServiceUser.belongsTo(Service, {foreignKey: 'id_service'})
ServiceUser.belongsTo(Admin, {foreignKey: 'id_admin'})

//MODEL User
User.hasMany(Appoiment, {foreignKey: 'id_user'})

//MODEL Appoiment
Appoiment.belongsTo(Admin, {foreignKey: 'id_admin_service'})
// Appoiment.belongsTo(Admin, {foreignKey: 'id_admin_finish'})
// Appoiment.belongsTo(Admin, {foreignKey: 'id_admin_update'})
Appoiment.belongsTo(User, {foreignKey: 'id_user'})
Appoiment.hasMany(DescriptionAppoiment, {foreignKey: 'id_appoiment'})

//MODEL DescriptionAppoiment
DescriptionAppoiment.belongsTo(Service, {foreignKey: 'id_service'})
DescriptionAppoiment.belongsTo(Appoiment, {foreignKey: 'id_appoiment'})


