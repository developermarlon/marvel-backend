const express = require('express')
const app = express()

const moment = require('moment-timezone')
moment().tz("America/Bogota").format()

const NODE_ENV = process.env.NODE_ENV || 'development'
require('dotenv').config({
    path: `.env.${NODE_ENV}`
})

const morgan = require('morgan')
const fileUpload = require('express-fileupload')
const cors = require('cors')
const port = 2000
const sequelize = require('./database/db')
require('./database/asociations')

//PERMITIR INTERCAMBIO DE RECURSOS DE OTROS SERVIDORES
app.use(cors())
 
//VALIDAR EL PUERTO POR DEFAULT
app.set('port', process.env.PORT || port)
app.set('trust proxy', true)

//LEVANTA EL SERVICIO CON EL PROTOCOLO HTTP
const server = app.listen(app.get('port'), function(){
  console.log("My http server listening on port " + app.get('port') + "...");
  // sequelize.authenticate().then(() => {
  sequelize.sync({force: false}).then(() => {    
    console.log('conexion mediante sequelize')
  })
  .catch(error => {
    console.log(error) 
  })
})

//MIDDLEWARES
app.use(morgan('dev'))
app.use(express.json())
app.use(express.urlencoded({extended: false}))

//PARAMETROS DE ARCHIVOS ENTRANTES
app.use(fileUpload({
  createParentPath: true,
  limits: {fileSize: 10 * 1024 * 1024},
  limitHandler: (req, res, next) => {
      req.validateLimit = true
  },
  abortOnLimit: true,
}))

//DIRECTORIO PUBLICO
app.use(express.static(__dirname + '/public'))

//RUTAS DE PETICIONES
app.use(require('./routes/user'))
app.use(require('./routes/admin'))
app.use(require('./routes/working-times'))
app.use(require('./routes/work-permit'))
app.use(require('./routes/service'))
app.use(require('./routes/service-user'))
app.use(require('./routes/web-push'))
app.use(require('./routes/appoiment'))

require('./functions/web-push.js')


