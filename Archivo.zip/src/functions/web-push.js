const moment = require('moment-timezone')
const Admin = require('../database/models/admin')
const User = require('../database/models/user')
const Service = require('../database/models/service')
const ServiceUser = require('../database/models/service-user')
const Appoiment = require('../database/models/appoiment')
const DescriptionAppoiment = require('../database/models/description-appoiment')
const {Op} = require('sequelize')
const WebPushModel = require('../database/models/web-push')
const webpush = require('web-push')
webpush.setVapidDetails('mailto:goodcode.info@gmail.com', process.env.PUBLIC_VAPID_KEY, process.env.PRIVATE_VAPID_KEY)


const loopNotification = async () => {

  let appoiments = await Appoiment.findAll({
    where: {
      state: 1,
      state_notification: 0,
      date_notification: {
        // [Op.lt]: moment('2021-01-18 08:20:00', 'YYYY-MM-DD HH:mm:ss'),
        [Op.lt]: moment().format('YYYY-MM-DD HH:mm:ss')
      }
    },
    include: [ 
      {
          model: Admin,
          required: false,
      },
      {
        model: User,
        required: false,
      }
    ]
  })

  for(let a = 0; a < appoiments.length; a++){
    let appoiment = appoiments[a].dataValues
    let admin = appoiments[a].dataValues.admin.dataValues
    let user = appoiments[a].dataValues.user.dataValues
    let last_ip_login_user = user.last_ip_login
    let last_ip_login_admin = admin.last_ip_login

    if(last_ip_login_user !== null){ 
      let info_push_user = await WebPushModel.findAll({
        where: {
          ip: last_ip_login_user 
        }
      })

      if(info_push_user.length > 0){
        let payload_user = await JSON.stringify({
          title: 'Recordatorio cita '+formatterDate(appoiment.date_appoiment),
          message: 'Toca la notificacion para confirmar tu cita',
          icon: process.env.URL_FRONT+'/static/social.png',
          badge: process.env.URL_FRONT+'/static/social.png',
          url: process.env.URL_FRONT+'/confirmation-appoiment?ap='+appoiment.id_appoiment,
          vibrate: [200, 100, 200] 
        })  
        await webpush.sendNotification(info_push_user[0].dataValues.subscription, payload_user)

        await Appoiment.update({
          state_notification: 1
        },{
          where: {
            id_appoiment: appoiment.id_appoiment
          }
        })
      }
    } 
  }

  setTimeout(() => {
    loopNotification()
  }, 20000)
}

const formatterDate = (date) => {
  var date = new Date(date);
  var options = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
    weekday: 'long'
  }
  return date.toLocaleTimeString("es-ES", options)
}

loopNotification()
