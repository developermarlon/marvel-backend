const { Router } = require('express');

const router = Router();

const { routsToken, verifyToken } = require('../controllers/token.controller')
const { createUser, login, verificationEmail, uploadPhotoUser, getUsers, updateUser, updatePassword, updatePasswordProfile, getDatesAccount, updateAccount } = require('../controllers/user.controller')

router.post('/api/users/createUser', createUser);
router.post('/api/users/login', login);
router.put('/api/users/verifyEmail', verificationEmail);
router.post('/api/users/verifyToken', verifyToken);
router.post('/api/users/uploadPhotoUser', routsToken, uploadPhotoUser)
router.post('/api/users/getUsers', routsToken, getUsers)
router.post('/api/user/updateUser', routsToken, updateUser)
router.post('/api/users/updatePassword', routsToken, updatePassword)
router.post('/api/users/updatePasswordProfile', routsToken, updatePasswordProfile)
router.post('/api/users/getDatesAccount', routsToken, getDatesAccount)
router.post('/api/users/updateAccount', routsToken, updateAccount)

module.exports = router;