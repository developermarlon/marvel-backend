const { Router } = require('express')

const router = Router()

const {routsTokenAdmin } = require('../controllers/token.controller')

const {sendNotification, activate, inactivate} = require('../controllers/web-push.controller.js')

router.post('/api/web-push/sendNotification', sendNotification)
router.post('/api/web-push/activate', activate)
router.post('/api/web-push/inactivate', inactivate)

module.exports = router