const { Router } = require('express')

const router = Router()

const {routsTokenAdmin } = require('../controllers/token.controller')

const {create, update, deleteServiceUser, getServiceUserByService } = require('../controllers/service-user.controller.js')

router.post('/api/service-user/create', routsTokenAdmin, create)
router.post('/api/service-user/getServiceUserByService', routsTokenAdmin, getServiceUserByService)
router.post('/api/service-user/update', routsTokenAdmin, update)
router.post('/api/service-user/deleteServiceUser', routsTokenAdmin, deleteServiceUser)

module.exports = router