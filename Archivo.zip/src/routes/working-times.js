const { Router } = require('express')

const router = Router()

const {routsTokenAdmin} = require('../controllers/token.controller')

const {create, update, deleteTime, getWorkingTimesByAdmin} = require('../controllers/working-times.controller.js')

router.post('/api/working-times/create', routsTokenAdmin, create)
router.post('/api/working-times/getWorkingTimesByAdmin', routsTokenAdmin, getWorkingTimesByAdmin)
router.post('/api/working-times/update', routsTokenAdmin, update)
router.post('/api/working-times/deleteTime', routsTokenAdmin, deleteTime)

module.exports = router