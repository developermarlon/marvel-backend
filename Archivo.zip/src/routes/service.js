const { Router } = require('express');

const router = Router();

const { routsTokenAdmin, verifyTokenAdmin } = require('../controllers/token.controller')
const { createService, getServices, uploadPhotoService, deleteService, updateService } = require('../controllers/service.controller')

router.post('/api/services/verifyTokenAdmin', verifyTokenAdmin)
router.post('/api/services/getServices', routsTokenAdmin, getServices)
router.post('/api/services/uploadPhotoService', routsTokenAdmin, uploadPhotoService)
router.post('/api/services/createService', routsTokenAdmin, createService)
router.post('/api/services/deleteService', routsTokenAdmin, deleteService)
router.post('/api/services/updateService', routsTokenAdmin, updateService)

module.exports = router;