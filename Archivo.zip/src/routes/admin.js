const { Router } = require('express');

const router = Router();

const { routsTokenAdmin, verifyTokenAdmin } = require('../controllers/token.controller')
const { createDefaultTypes, login, createDefaultAdmin, createAdmin, example, getAdmins, getDatesAccount, getTypes, getBarbers, uploadPhotoAdmin, deleteAdmin, updateAdmin, updateAccount, updatePassword, updatePasswordProfile } = require('../controllers/admin.controller')


router.post('/api/admins/createDefaultTypes', createDefaultTypes)
router.post('/api/admins/createDefaultAdmin', createDefaultAdmin)
router.post('/api/admins/login', login)

router.post('/api/admins/verifyTokenAdmin', verifyTokenAdmin)
router.post('/api/admins/example', routsTokenAdmin, example)
router.post('/api/admins/getAdmins', routsTokenAdmin, getAdmins)
router.post('/api/admins/getTypes', routsTokenAdmin, getTypes)
router.post('/api/admins/getBarbers', routsTokenAdmin, getBarbers)
router.post('/api/admins/uploadPhotoAdmin', routsTokenAdmin, uploadPhotoAdmin)
router.post('/api/admins/createAdmin', routsTokenAdmin, createAdmin)
router.post('/api/admins/deleteAdmin', routsTokenAdmin, deleteAdmin)
router.post('/api/admins/updateAdmin', routsTokenAdmin, updateAdmin)
router.post('/api/admins/updatePassword', routsTokenAdmin, updatePassword)
router.post('/api/admins/updatePasswordProfile', routsTokenAdmin, updatePasswordProfile)
router.post('/api/admins/getDatesAccount', routsTokenAdmin, getDatesAccount)
router.post('/api/admins/updateAccount', routsTokenAdmin, updateAccount)

module.exports = router;