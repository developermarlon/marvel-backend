const { Router } = require('express');

const router = Router();

const { routsToken, routsTokenAdmin, verifyToken } = require('../controllers/token.controller')
const { getBarbersInfoAppoiment, getBarbers, getServices, createAppoiment, getAppoimentsAdmin, getAppoimentsUser, updateAppoimentAdmin, updateAppoimentUser, cancelAppoimentUser, confirmAppoimentUser, confirmAppoimentNotification } = require('../controllers/appoiment.controller')

router.post('/api/appoiments/getBarbersInfoAppoiment', getBarbersInfoAppoiment)
router.post('/api/appoiments/getServices', getServices)
router.post('/api/appoiments/createAppoiment', routsToken, createAppoiment)
router.post('/api/appoiments/getAppoimentsAdmin', routsTokenAdmin, getAppoimentsAdmin)
router.post('/api/appoiments/getAppoimentsUser', routsToken, getAppoimentsUser)
router.post('/api/appoiments/getBarbers', routsToken, getBarbers)
router.post('/api/appoiments/updateAppoimentAdmin', routsTokenAdmin, updateAppoimentAdmin)
router.post('/api/appoiments/updateAppoimentUser', routsToken, updateAppoimentUser)
router.post('/api/appoiments/cancelAppoimentUser', routsToken, cancelAppoimentUser)
router.post('/api/appoiments/confirmAppoimentUser', routsToken, confirmAppoimentUser)
router.post('/api/appoiments/confirmAppoimentNotification', confirmAppoimentNotification)

module.exports = router;