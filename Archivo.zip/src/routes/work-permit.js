const { Router } = require('express')

const router = Router()

const {routsTokenAdmin } = require('../controllers/token.controller')

const {create, update, deletePermit, getWorkPermitByAdmin} = require('../controllers/work-permit.controller.js')

router.post('/api/work-permit/create', routsTokenAdmin, create)
router.post('/api/work-permit/getWorkPermitByAdmin', routsTokenAdmin, getWorkPermitByAdmin)
router.post('/api/work-permit/update', routsTokenAdmin, update)
router.post('/api/work-permit/deletePermit', routsTokenAdmin, deletePermit)

module.exports = router