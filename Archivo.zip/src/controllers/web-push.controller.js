const WebPushModel = require('../database/models/web-push')
const User = require('../database/models/user')
const Admin = require('../database/models/admin')
const webpush = require('web-push')

const DeviceDetector = require('node-device-detector')
const detector = new DeviceDetector;

webpush.setVapidDetails('mailto:goodcode.info@gmail.com', process.env.PUBLIC_VAPID_KEY, process.env.PRIVATE_VAPID_KEY)



const infoDevice = async (userAgent) => {
    const result = await detector.detect(userAgent)
    return result
}

const activate = async (req, res) => {
  try{

    const {subscription} = req.body

    let ip = process.env.NODE_ENV === 'production' ? req.ip : '147.75.115.226'
    ip = ip.split(':')[0]

    //GET DEVICE
    const result_device = await infoDevice(req.headers['user-agent'])

    const count = await WebPushModel.count({
      where: {
        ip,
        device_type: result_device.device.type,
        device_brand: result_device.device.brand,
        device_model: result_device.device.model,
        client_name: result_device.client.name,
        os_name: result_device.os.name,
        os_version: result_device.os.version
      }
    })

    if(count > 0){
      const update = await WebPushModel.update({
        subscription,
        state: 1
      },{
        where: {
          ip
        }
      })
    }else{
      const create = await WebPushModel.create({
        state: 1,
        ip,
        subscription,
        device_type: result_device.device.type,
        device_brand: result_device.device.brand,
        device_model: result_device.device.model,
        client_name: result_device.client.name,
        os_name: result_device.os.name,
        os_version: result_device.os.version
      })
    }

    res.status(200).json({
      message: "WebPush Activo"
    })

    let users = new Array()

    const find_users = await User.findAll({
      where: {
        last_ip_login: ip
      }
    })

    const find_admins = await Admin.findAll({
      where: {
        last_ip_login: ip
      }
    })

    users = find_users.concat(find_admins)

    for(let i = 0; i < users.length; i ++){
      
      const web_push = await WebPushModel.findOne({
        where: {
          ip: users[i].last_ip_login
        }
      })
      
      const payload = await JSON.stringify({
        title: '😃 Notificaciones Activas 💥',
        message: 'Ahora podras estar al tanto de tus citas',
        icon: process.env.URL_FRONT+'/static/social.png',
        badge: process.env.URL_FRONT+'/static/social.png',
        url: 'https://labarberbrothers.com.co',
        vibrate: [200, 100, 200]
      })
  
      const send = await webpush.sendNotification(web_push.dataValues.subscription, payload)

    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: "Error interno en el servidor"
    })
  }
}





const inactivate = async (req, res) => {
  try{
    let ip = process.env.NODE_ENV === 'production' ? req.ip : '147.75.115.226'
    ip = ip.split(':')[0]

    //GET DEVICE
    const result_device = await infoDevice(req.headers['user-agent'])

    const count = await WebPushModel.count({
      where: {
        ip,
        device_type: result_device.device.type,
        device_brand: result_device.device.brand,
        device_model: result_device.device.model,
        client_name: result_device.client.name,
        os_name: result_device.os.name,
        os_version: result_device.os.version
      }
    })

    if(count > 0){
      const update = await WebPushModel.update({
        state: 0
      },{
        where: {
          ip
        }
      })

      res.status(200).json({
        message: "WebPush Actualizado"
      })
    }else{
      const create = await WebPushModel.create({
        state: 0,
        ip: ip,
        subscription: null,
        device_type: result_device.device.type,
        device_brand: result_device.device.brand,
        device_model: result_device.device.model,
        client_name: result_device.client.name,
        os_name: result_device.os.name,
        os_version: result_device.os.version
      })

      res.status(200).json({
        message: "WebPush Creado"
      })
    }

  }catch(error){
    console.log(error)
  }
}

const sendNotification = async (req, res) => {

    try{

        // const ip = req.ip

      // const geoip = require('geoip-lite')
      // const ip = "147.75.115.226"
      // const geo = geoip.lookup(ip)
      // console.log(geo)
      // res.json(geo)

      const ip = '147.75.115.226'
      const GeoIP = require("simple-geoip")
      let geoIP = new GeoIP(process.env.GEOIP_KEY)
      geoIP.lookup(ip, (err, data) => {
        if (err) {
          console.log(err)
          res.json(err)
        }else{
          console.log(data)
          res.json(data)
        }
      })

      // const userAgent  = req.headers['user-agent']
      // const device = await infoDevice(userAgent)

      // console.log(device)
      // res.json(device)

        // const { push_subscription, title, message, icon, badge, url } = req.body
        // const payload = JSON.stringify({
        //     title,
        //     message,
        //     icon,
        //     badge,
        //     url,
        //     vibrate: [200, 100, 200]
        // })

        // await webpush.sendNotification(push_subscription, payload)
        
        // res.status(200).json({
        //     message: "Mensaje Enviado"
        // })

    }catch(error){
        res.status(500).json({
            message: String(error)
        })
    }

}


module.exports = {
    sendNotification,
    activate,
    inactivate
}