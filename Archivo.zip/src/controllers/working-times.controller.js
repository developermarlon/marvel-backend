const WorkingTime = require('../database/models/working-time')
const moment = require('moment-timezone')
const {Op} = require('sequelize')

const create = async (req, res) => {
  try {

    const {
      day, start_time, end_time, state, id_admin
    } = req.body

    // const countTime = await WorkingTime.count({
    //   where: {
    //     id_admin,
    //     start_time: {
    //       [Op.lte]: start_time
    //     },
    //     end_time: {
    //       [Op.gte]: end_time
    //     },
    //     [Op.or]: {
    //       start_time: {
    //         [Op.gte]: start_time
    //       },
    //       end_time: {
    //         [Op.lte]: end_time
    //       }
    //     }
    //   }
    // })

    const create = await WorkingTime.create({
      day, start_time: moment(start_time).format("HH:mm:ss"), end_time: moment(end_time).format("HH:mm:ss"), state, id_admin
    })

    console.log(create)

    res.status(200).json({
      message: 'Creado correctamente'
    })

  }catch(error) {
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const update = async (req, res) => {
  try{

    const {
      day, start_time, end_time, state, id_admin, id_working_time
    } = req.body
    const update = await WorkingTime.update({
      day, start_time: moment(start_time).format("HH:mm:ss"), end_time: moment(end_time).format("HH:mm:ss"), state
    },{
      where: {
        id_working_time,
        id_admin
      }
    })

    if(update > 0){
      res.status(200).json({
        message: 'Editado correctamente'
      })
    }else{
      res.status(400).json({
        message: 'Problemas al actualizar, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const getWorkingTimesByAdmin = async (req, res) => {
  try{
    const {
      id_admin,
      day,
      state
    } = req.body

    let conditionTypeUser = new Object({
      id_admin
    })
    if(day !== null){
        conditionTypeUser['day'] = day
    }
    if(state !== null){
      conditionTypeUser['state'] = state
    } 

    const result = await WorkingTime.findAll({
      where: conditionTypeUser
    })

    res.status(200).json(result)

  }catch(error) {
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const deleteTime = async (req, res) => {
  try{

    const {
      id_working_time
    } = req.body

    const destroy = await WorkingTime.destroy({
      where: {
        id_working_time
      }
    })

    if(destroy > 0){
      res.status(200).json({
        message: 'Eliminado correctamente'
      })
    }else{
      res.status(400).json({
        message: 'Problemas al eliminar, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

module.exports = {
  create,
  update,
  getWorkingTimesByAdmin,
  deleteTime
}