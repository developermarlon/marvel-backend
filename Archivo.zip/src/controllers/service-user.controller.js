const WorkPermit = require('../database/models/work-permit')
const ServiceUser = require('../database/models/service-user')
const Admin = require('../database/models/admin')
const moment = require('moment-timezone')
const {Op} = require('sequelize')

const create = async (req, res) => {
  try {

    const {
      id_admin, id_service, state, observation, porcentage
    } = req.body

    const countAdmin = await ServiceUser.count({
      where: {
        id_admin,
        id_service
      }
    })

    if(countAdmin == 0){
      const create = await ServiceUser.create({
        id_admin, id_service, observation, state, porcentage
      })

      res.status(200).json({
        message: 'Creado correctamente'
      })
    }else{
      res.status(400).json({
        message: 'Este usuario ya se encuentra registrado en el servicio'
      })
    }

  }catch(error) {
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const update = async (req, res) => {
  try{

    const {
      id_service_user, state, id_admin, observation, porcentage
    } = req.body

    const update = await ServiceUser.update({
      state, id_admin, observation, porcentage
    },{
      where: {
        id_service_user
      }
    })

    if(update > 0){
      res.status(200).json({
        message: 'Editado correctamente'
      })
    }else{
      res.status(400).json({
        message: 'Problemas al actualizar, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const getServiceUserByService = async (req, res) => {
  try{
    const {
      id_service,
      start_date,
      end_date,
      state
    } = req.body

    let conditionServiceUser = new Object({
      id_service
    })

    if(start_date !== null && String(start_date).trim() !== '' && end_date !== null && String(end_date).trim()){
      conditionServiceUser['createdAt'] = {
          [Op.between]: [moment(start_date).format("YYYY-MM-DD HH:mm:ss"), moment(end_date).format("YYYY-MM-DD HH:mm:ss")]
      }
    }

    if(state !== null){
      conditionServiceUser['state'] = state
    }

    const result = await ServiceUser.findAll({
      where: conditionServiceUser,
      include: [{
        model: Admin,
        required: true
      }]
    })

    res.status(200).json(result)

  }catch(error) {
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const deleteServiceUser = async (req, res) => {
  try{

    const {
      id_service_user
    } = req.body

    const destroy = await ServiceUser.destroy({
      where: {
        id_service_user
      }
    })

    if(destroy > 0){
      res.status(200).json({
        message: 'Eliminado correctamente'
      })
    }else{
      res.status(400).json({
        message: 'Problemas al eliminar, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

module.exports = {
  create,
  update,
  getServiceUserByService,
  deleteServiceUser
}