
    //new Date(data.birthday).toISOString().substr(0, 10)
    //<input type="number" placeholder="Ej: 1.5 mts" v-model="update.height" step="0.01">

    //TIPOS DE CONSULTAS =================================================
    //CREAR
    // try {
    //     const create_user = await User.create({ // SE VA HACIA EL CATCH CUANDO NO PUEDE INSERTAR
    //         id_usr: 9,
    //         name,
    //         last_name,
    //         email,
    //         password: encriptPassword,
    //         verification_code: verificationCode,
    //         verified_account: 0
    //     })
    //     console.log(create_user.dataValues)
    // }catch(error){
    //     console.log('NO SE PUDO INSERTAR')
    // }

    //CONTAR
    // const count_user = await User.count({//RETORNA LA CANTIDAD ENCONTRADA DE REGISTROS
    //     where: {
    //         email: email
    //     }
    // })
    // console.log(count_user)


    //ENCONTRAR
    // const { Op } = require('sequelize');
    // const countUser = await User.findAll({
    //     where: {
    //         email: {
    //             [Op.ne]: 'alguno'
    //         }
    //     }
    // })
    // // console.log(countUser.length)
    // // console.log(countUser[0].dataValues)

    //ACTUALIZAR
    // const update  = await User.update({ //RETORNA CUANTOS RESULTADOS ACTUALIZO
    //     name: 'OTRO NOMBRE'
    // },{
    //     where: {
    //         id_usr: 1
    //     }
    // })
    // console.log(update)

    //ELIMINAR
    // const deleted = await User.destroy({ //RETORNA CUANTOS REGISTROS ELIMINO
    //     where: {
    //       id_usr: 1
    //     }
    // });
    // console.log(deleted)


    //TIPO DE DATOS =================================================
    //STRINGS
    // DataTypes.STRING             // VARCHAR(255)
    // DataTypes.STRING(1234)       // VARCHAR(1234)
    // DataTypes.STRING.BINARY      // VARCHAR BINARY
    // DataTypes.TEXT               // TEXT
    // DataTypes.TEXT('tiny')       // TINYTEXT
    // DataTypes.CITEXT             // CITEXT      
    
    //BOOLEAN
    // DataTypes.BOOLEAN            // TINYINT(1)

    //NUMBERS
    // DataTypes.INTEGER            // INTEGER
    // DataTypes.BIGINT             // BIGINT
    // DataTypes.BIGINT(11)         // BIGINT(11)

    // DataTypes.FLOAT              // FLOAT
    // DataTypes.FLOAT(11)          // FLOAT(11)
    // DataTypes.FLOAT(11, 10)      // FLOAT(11,10)

    // DataTypes.REAL               // REAL            PostgreSQL only.
    // DataTypes.REAL(11)           // REAL(11)        PostgreSQL only.
    // DataTypes.REAL(11, 12)       // REAL(11,12)     PostgreSQL only.

    // DataTypes.DOUBLE             // DOUBLE
    // DataTypes.DOUBLE(11)         // DOUBLE(11)
    // DataTypes.DOUBLE(11, 10)     // DOUBLE(11,10)

    // DataTypes.DECIMAL            // DECIMAL
    // DataTypes.DECIMAL(10, 2)     // DECIMAL(10,2)

    //DATES
    // DataTypes.DATE       // DATETIME for mysql / sqlite, TIMESTAMP WITH TIME ZONE for postgres
    // DataTypes.DATE(6)    // DATETIME(6) for mysql 5.6.4+. Fractional seconds support with up to 6 digits of precision
    // DataTypes.DATEONLY   // DATE without time


    //OPERADORES =================================================
    // Post.findAll({
    //     where: {
    //       [Op.and]: [{ a: 5 }, { b: 6 }],            // (a = 5) AND (b = 6)
    //       [Op.or]: [{ a: 5 }, { b: 6 }],             // (a = 5) OR (b = 6)
    //       someAttribute: {
    //         // Basics
    //         [Op.eq]: 3,                              // = 3
    //         [Op.ne]: 20,                             // != 20
    //         [Op.is]: null,                           // IS NULL
    //         [Op.not]: true,                          // IS NOT TRUE
    //         [Op.or]: [5, 6],                         // (someAttribute = 5) OR (someAttribute = 6)
      
    //         // Using dialect specific column identifiers (PG in the following example):
    //         [Op.col]: 'user.organization_id',        // = "user"."organization_id"
      
    //         // Number comparisons
    //         [Op.gt]: 6,                              // > 6
    //         [Op.gte]: 6,                             // >= 6
    //         [Op.lt]: 10,                             // < 10
    //         [Op.lte]: 10,                            // <= 10
    //         [Op.between]: [6, 10],                   // BETWEEN 6 AND 10
    //         [Op.notBetween]: [11, 15],               // NOT BETWEEN 11 AND 15
      
    //         // Other operators
      
    //         [Op.all]: sequelize.literal('SELECT 1'), // > ALL (SELECT 1)
      
    //         [Op.in]: [1, 2],                         // IN [1, 2]
    //         [Op.notIn]: [1, 2],                      // NOT IN [1, 2]
      
    //         [Op.like]: '%hat',                       // LIKE '%hat'
    //         [Op.notLike]: '%hat',                    // NOT LIKE '%hat'
    //         [Op.startsWith]: 'hat',                  // LIKE 'hat%'
    //         [Op.endsWith]: 'hat',                    // LIKE '%hat'
    //         [Op.substring]: 'hat',                   // LIKE '%hat%'
    //         [Op.iLike]: '%hat',                      // ILIKE '%hat' (case insensitive) (PG only)
    //         [Op.notILike]: '%hat',                   // NOT ILIKE '%hat'  (PG only)
    //         [Op.regexp]: '^[h|a|t]',                 // REGEXP/~ '^[h|a|t]' (MySQL/PG only)
    //         [Op.notRegexp]: '^[h|a|t]',              // NOT REGEXP/!~ '^[h|a|t]' (MySQL/PG only)
    //         [Op.iRegexp]: '^[h|a|t]',                // ~* '^[h|a|t]' (PG only)
    //         [Op.notIRegexp]: '^[h|a|t]',             // !~* '^[h|a|t]' (PG only)
      
    //         [Op.any]: [2, 3],                        // ANY ARRAY[2, 3]::INTEGER (PG only)
      
    //         // In Postgres, Op.like/Op.iLike/Op.notLike can be combined to Op.any:
    //         [Op.like]: { [Op.any]: ['cat', 'hat'] }  // LIKE ANY ARRAY['cat', 'hat']
      
    //         // There are more postgres-only range operators, see below
    //       }
    //     }
    //   });


    //FUNCIONES =================================================
    //FUNCION COUNT AS
    // Model.findAll({
    //     attributes: [[sequelize.fn('COUNT', sequelize.col('hats')), 'no_hats']]
    // });
    // SELECT COUNT(hats) AS no_hats ...

    //A veces puede resultar tedioso enumerar todos los atributos del modelo si solo desea agregar una agregación:

    // INCLUDE EXCLUDE
    // Model.findAll({
    //     attributes: ['id', 'foo', 'bar', 'baz', 'quz', [sequelize.fn('COUNT', sequelize.col('hats')), 'no_hats']]
    //   });
    
    //   // This is shorter, and less error prone because it still works if you add / remove attributes
    //   Model.findAll({
    //     attributes: { include: [[sequelize.fn('COUNT', sequelize.col('hats')), 'no_hats']] }
    //   });
    //   SELECT id, foo, bar, baz, quz, COUNT(hats) AS no_hats ...
    //   Del mismo modo, también es posible eliminar algunos atributos seleccionados:
    
    //   Model.findAll({
    //     attributes: { exclude: ['baz'] }
    //   });
    //   SELECT id, foo, bar, quz ...
