const fs = require('fs')
const Service = require('../database/models/service')
const ServiceUser = require('../database/models/service-user')
const moment = require('moment-timezone')
const {Op} = require('sequelize')

const moveImage = ({ routeImage, file}) => {
  return new Promise((resolve, reject) => {
      file.mv(routeImage, err => {
          if(err) {
              reject(err)
          }else{
              resolve()
          }
      })
  })
}



const mkDir = async (dir) => {
  return new Promise((resolve, reject) => {
      let arregloCarpetas = dir.replace('.', '').split('/')
      let carpetas = './'
      for (var i=1; i < arregloCarpetas.length; i++) {
          carpetas += arregloCarpetas[i]+'/'
          if (!fs.existsSync(carpetas)){
              fs.mkdirSync(carpetas);
          }
      }
      resolve()
  })
}

const uploadImage = async ({file, dir}) =>{

  let routeImage = `${dir+file.name}`

  return mkDir(dir)
  .then(res => {
      return moveImage({file, routeImage})
  })
  .then(res => {
      return {
          routeImage: routeImage.replace('./src/public/', '/'),
          message: 'Foto subida con exito'
      }
  })
  .catch(error => {
      console.log('entro en este error')
      return {
          function: false,
          title: '😞',
          message : error
      }
  })

}

const uploadPhotoService = async (req, res, next) => {
    try{
      if(req.files && !req.validateLimit){
          let file = req.files.photo

          if(file.mimetype == 'image/jpg' || file.mimetype == 'image/jpeg' || file.mimetype == 'image/png'){
              let route = `./src/public/images/services/`
              uploadImage({
                  file: file,
                  dir: route
              })
              .then(msg => {
                  res.status(200).json(msg)
              })
              .catch(error => {
                  console.log(error)
                  res.status(400).json({
                    message: 'Tenemos problemas al subir el archivo, comuniquese con los administradores'
                  })
              })

          }else{
            
              res.status(400).json({
                message: 'Tenemos problemas al subir el archivo, comuniquese con los administradores'
              });
          }

      }else{
          res.status(400).json({
              message : 'La imagen supera el maximo de tamaño permitido (7mb)'
          });
      }

  }catch(error){
    console.log(error)
    res.status(500).json({
        message : String(error)
    });
  }
}

const createService = async (req, res) => {

    try{
        const {
          photo,
          name,
          description,
          price,
          minutes,
          state
        } = req.body

        if(
            name !== null &&
            description !== null && 
            photo !== null &&
            price !== null &&
            minutes !== null &&
            state !== null 
        ){
        
            try {
  
                const response = await Service.create({
                  photo,
                  name,
                  price: parseInt(String(price).trim().split(".").join("")),
                  minutes,
                  description,
                  state
                })
  
                res.status(200).json({
                    message: 'Servicio creado'
                })
            }catch(error){
                console.log(error)
                res.status(400).json({
                    message: 'No es posible crear este servicio, comuniquese con los administradores'
                })
            }

        }else{
            res.status(400).json({
                message: 'Complete los campos del formulario'
            })
        }
  
    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error en el servidor'
        })
    }
  
  }

const getServices = async (req, res) => {
    try{
        const {
          state,
          start_date,
          end_date,
        } = req.body

        let conditionServices = new Object()

        if(state !== null){
          conditionServices['state'] = state
        }

        if(start_date !== null && String(start_date).trim() !== '' && end_date !== null && String(end_date).trim()){
            conditionAdmin['createdAt'] = {
                [Op.between]: [moment(start_date).format("YYYY-MM-DD HH:mm:ss"), moment(end_date).format("YYYY-MM-DD HH:mm:ss")]
            }
        }

        let services = await Service.findAll({
            where: conditionServices,
            include: [{
                model: ServiceUser,
                required: false
            }]
        })

        res.status(200).json(services)

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const deleteService = async (req, res) => {
    try{
        const {
            id_service
        } = req.body

        const del = await Service.destroy({
            where: {
                id_service
            }
        })

        if(del > 0){
            res.status(200).json({
                message: 'Servicio eliminado'
            })
        }else{
            res.status(400).json({
                message: 'No es posible eliminar este servicio'
            })
        }
    }catch(error) {
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updateService = async (req, res) => {
    try{

        const {
            id_service,
            photo,
            name,
            price,
            minutes,
            description,
            state
        } = req.body

        if(id_service !== null &&
            photo !== null &&
            name !== null &&
            description !== null &&
            price !== null &&
            minutes !== null &&
            state!== null){

                const updateService = await Service.update({
                    photo,
                    name,
                    price: parseInt(String(price).trim().split(".").join("")),
                    minutes,
                    description,
                    state
                },
                {
                    where: {
                        id_service
                    }
                })

                if(updateService > 0){
                    res.status(200).json({
                        message: 'Servicio actualizado exitosamente'
                    })
                }else{
                    res.status(400).json({
                        message: 'No es posible actualizar este servicio'
                    })
                }

        }else{
            res.status(400).json({
                message: 'Complete los campos del formulario'
            })
        }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

 
module.exports = {
    createService,
    getServices,
    uploadPhotoService,
    deleteService,
    updateService
}