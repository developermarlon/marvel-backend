const jwt = require('jsonwebtoken')
const fs = require('fs');
const bcrypt = require('bcrypt')
const Admin = require('../database/models/admin')
const Service = require('../database/models/service')
const ServiceUser = require('../database/models/service-user')
const Appoiment = require('../database/models/appoiment')
const DescriptionAppoiment = require('../database/models/description-appoiment')
const TypeUser = require('../database/models/type-user')
const WorkingTime = require('../database/models/working-time')
const WorkPermit = require('../database/models/work-permit')
const moment = require('moment-timezone')
const {Op} = require('sequelize')

const jwt_decode  = require('jwt-decode')

//DETECT DEVICE
const DeviceDetector = require('node-device-detector')
const detector = new DeviceDetector;

//DETECT GEO IP
const GeoIP = require("simple-geoip");
const geoIP = new GeoIP(process.env.GEOIP_KEY)

const moveImage = ({ routeImage, file}) => {
  return new Promise((resolve, reject) => {
      file.mv(routeImage, err => {
          if(err) {
              reject(err)
          }else{
              resolve()
          }
      })
  })
}

const mkDir = async (dir) => {
  return new Promise((resolve, reject) => {
      let arregloCarpetas = dir.replace('.', '').split('/')
      let carpetas = './'
      for (var i=1; i < arregloCarpetas.length; i++) {
          carpetas += arregloCarpetas[i]+'/'
          if (!fs.existsSync(carpetas)){
              fs.mkdirSync(carpetas);
          }
      }
      resolve()
  })
}

const uploadImage = async ({file, dir}) =>{

  let routeImage = `${dir+file.name}`

  return mkDir(dir)
  .then(res => {
      return moveImage({file, routeImage})
  })
  .then(res => {
      return {
          routeImage: routeImage.replace('./src/public/', '/'),
          message: 'Foto subida con exito'
      }
  })
  .catch(error => {
      console.log('entro en este error')
      return {
          function: false,
          title: '😞',
          message : error
      }
  })

}

const uploadPhotoAdmin = async (req, res, next) => {
  
    try{
      if(req.files && !req.validateLimit){
          let file = req.files.photo

          if(file.mimetype == 'image/jpg' || file.mimetype == 'image/jpeg' || file.mimetype == 'image/png'){
              let route = `./src/public/images/profile_pictures/admins/`
              uploadImage({
                  file: file,
                  dir: route
              })
              .then(msg => {
                  res.status(200).json(msg)
              })
              .catch(error => {
                  console.log(error)
                  res.status(400).json({
                    message: 'Tenemos problemas al subir el archivo, comuniquese con los administradores'
                  })
              })

          }else{
            
              res.status(400).json({
                message: 'Tenemos problemas al subir el archivo, comuniquese con los administradores'
              });
          }

      }else{
          res.status(400).json({
              message : 'La imagen supera el maximo de tamaño permitido (7mb)'
          });
      }

  }catch(error){
    console.log(error)
    res.status(500).json({
        message : String(error)
    });
  }
}

const createAdmin = async (req, res) => {

    try{
        const {
            name,
            last_name,
            type_user,
            email,
            phone,
            password,
            photo,
            state
        } = req.body

        if(
            name !== null &&
            last_name !== null &&
            type_user !== null &&
            email !== null &&
            phone !== null &&
            password !== null &&
            photo !== null &&
            state !== null 
        ){
  
        const encript_password = await bcrypt.hash(password, 10)
  
        const countUser = await Admin.count({
            where: {
                email: String(email).trim()
            }
        })
        
        if(countUser > 0){
            res.status(400).json({
                message: 'Este usuario ya se encuentra registrado'
            })
        }else{
            try {
  
                const admin = await Admin.create({
                    name,
                    last_name,
                    email,
                    phone,
                    type_user,
                    password: encript_password,
                    photo,
                    state
                })
  
                res.status(200).json({
                    message: 'Usuario creado'
                })
            }catch(error){
                console.log(error)
                res.status(400).json({
                    message: 'No es posible crear este administrador, verifique que el tipo de usuario exista'
                })
            }
        }

        }else{
            res.status(400).json({
                message: 'Complete los campos del formulario'
            })
        }
  
    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error en el servidor'
        })
    }
  
  }

const createDefaultAdmin = async (req, res) => {

  try{
      const {
          name,
          last_name,
          email,
          password
      } = req.body

      const encript_password = await bcrypt.hash(password, 10)

      const countUser = await Admin.count({
          where: {
              email: email
          }
      })
      
      if(countUser > 0){
          res.status(400).json({
              message: 'El administrador ya se encuentra registrado'
          })
      }else{
          try {

              const admin = await Admin.create({
                  name,
                  last_name,
                  email,
                  type_user: 1,
                  password: encript_password,
                  photo: '/images/profile_pictures/admins/default/default-user.png',
                  state: 1
              })

              res.status(201).json({
                  message: 'Administrador creado'
              })
          }catch(error){
              console.log(error)
              res.status(400).json({
                  message: 'No es posible crear este administrador, verifique que el tipo de usuario exista'
              })
          }
      }

  }catch(error){
      console.log(error)
    //   console.log(error)
      res.status(500).json({
          message: 'Error en el servidor'
      })
  }

}

const infoDevice = async (userAgent) => {
    const result = await detector.detect(userAgent)
    return result
}

const login = async (req, res) => {

    try {

        const { email, password } = req.body
        let ip = process.env.NODE_ENV === 'production' ? req.ip : '147.75.115.226'
        ip = ip.split(':')[0]

        //GET DEVICE
        const result_device = await infoDevice(req.headers['user-agent'])

        //GET GEO_IP
        geoIP.lookup(ip, async (err, result_geo) => {

        let admin = await Admin.findOne({
            where: {
                email
            }
        })
        
        if(admin) {

          admin = admin.dataValues
          

          const validate_password = await bcrypt.compare(password, admin.password);
          
          if(validate_password){

            if(admin.state === 1) {

              const token = await jwt.sign({id: admin.id_admin}, process.env.SECRET_KEY, { expiresIn: '1d' })
              
              const update = await Admin.update({
                last_ip_login: ip,
                device_type: result_device.device.type,
                device_brand: result_device.device.brand,
                device_model: result_device.device.model,
                client_name: result_device.client.name,
                os_name: result_device.os.name,
                os_version: result_device.os.version,
                lat: result_geo.location.lat,
                lng: result_geo.location.lng,
                region: result_geo.location.region
              },{
                where: {
                    email
                }
              })

              res.status(200).json({
                  message: 'Bienvenido '+admin.name,
                  token,
                  id_admin: admin.id_admin,
                  email: admin.email,
                  name: admin.name,
                  photo: admin.photo,
                  last_name: admin.last_name,
                  type_user: admin
              })

            }else{
                res.status(400).json({
                    message: 'El usuario se encuentra inactivo'
                })
            }

          }else{
              res.status(400).json({
                  message: 'contraseña incorrecta'
              })
          }
        }else{
            res.status(400).json({
                message: 'El usuario no se encuentra registrado'
            })
        }

        })

    }catch(error) {
        console.log(error)
        res.status(500).json({
            message: 'error interno en el servidor'
        })
    }
}

const example = async (req, res, msg) => {
    try {

        const {
            type
        } = req.body

        let fecha_trabajador_inicio = new Date('2020-12-22 8:00:00')
        const fecha_trabajador_fin = new Date('2020-12-22 18:00:00')

        let arregloSecciones = new Array()
        let marker = new Date(fecha_trabajador_inicio)

        const servicios = [
            {
                fecha_inicio: new Date('2020-12-22 9:00:00'),
                detalle_servicio: [
                    {
                        time_minutes: 30
                    },
                    {
                        time_minutes: 30
                    },
                    {
                        time_minutes: 30
                    }
                ]
            },
            {
                fecha_inicio: new Date('2020-12-22 14:00:00'),
                detalle_servicio: [
                    {
                        time_minutes: 30
                    },
                    {
                        time_minutes: 30
                    },
                    {
                        time_minutes: 30
                    }
                ]
            },
            {
                fecha_inicio: new Date('2020-12-22 18:00:00'),
                detalle_servicio: []
            }
        ]

        

        while(fecha_trabajador_inicio <= fecha_trabajador_fin){

            for(let a = 0; a < servicios.length; a++){
                let countMinutes = 0
                let fechaFinalServicio = null
                for(let b = 0; b < servicios[a].detalle_servicio.length; b++){
                    countMinutes = countMinutes + servicios[a].detalle_servicio[b].time_minutes
                }

                fechaFinalServicio = new Date(servicios[a].fecha_inicio)
                await fechaFinalServicio.setMinutes(fechaFinalServicio.getMinutes()+countMinutes)

                if(fecha_trabajador_inicio >= servicios[a].fecha_inicio && fecha_trabajador_inicio <= fechaFinalServicio){

                    arregloSecciones.push({
                        fecha_inicio: marker,
                        fecha_fin: fecha_trabajador_inicio
                    })
                    fecha_trabajador_inicio = new Date(fechaFinalServicio)
                    marker = new Date(fechaFinalServicio)
                    marker.setSeconds(marker.getSeconds() + 1)
                }
    
            }

            fecha_trabajador_inicio.setSeconds(fecha_trabajador_inicio.getSeconds() + 1)
        }
        
        for(let a = 0; a < arregloSecciones.length; a++){
            console.log('fecha inicio: ', arregloSecciones[a].fecha_inicio+'')
            console.log('fecha fin: ', arregloSecciones[a].fecha_fin+'')
            console.log('++++++++++++++++++++++++++++++++++++')
        }

        res.status(200).json({
            message: type
        })

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const getAdmins = async (req, res) => {
    try{
        const {
            type_user,
            state,
            date_ini,
            date_fin
        } = req.body

        let conditionTypeUser = new Object()

        let conditionAdmin = new Object({
            type_user:{
                [Op.ne]: 1
            }
        })

        if(type_user !== null){
            conditionTypeUser['id_type'] = type_user
        }

        if(state !== null){
            conditionAdmin['state'] = state
        }

        if(date_ini !== null && String(date_ini).trim() !== '' && date_fin !== null && String(date_fin).trim()){
            conditionAdmin['createdAt'] = {
                [Op.between]: [moment(date_ini).format("YYYY-MM-DD HH:mm:ss"), moment(date_fin).format("YYYY-MM-DD HH:mm:ss")]
            }
        }

        let admins = await Admin.findAll({
            where: conditionAdmin,
            include: [{
                model: TypeUser,
                where: conditionTypeUser,
                required: true
            },{
                model: WorkingTime
            }]
        })

        res.status(200).json(admins)

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const getTypes = async (req, res) => {
    try{
        const types = await TypeUser.findAll({
            where: {
                id_type:{
                    [Op.ne]: 1
                }
            },
        })

        res.status(200).json(types)
    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const getDatesAccount = async (req, res) => {
    try{
        const id_admin = jwt_decode(req.headers.token).id

        const admin = await Admin.findOne({
            where: {
                id_admin
            }
        })

        res.status(200).json(admin)
    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}


const getBarbers = async (req, res) => {
    try{
        const barbers = await Admin.findAll({
            where: {
                type_user: 4,
                state: 1
            },
        })

        res.status(200).json(barbers)
    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const createDefaultTypes = async (req, res) => {
    try {
        const createTypes = await TypeUser.bulkCreate([
            {
                id_type: 1,
                name: 'Superusuario',
                state: 1
            },
            {
                id_type: 2,
                name: 'Administrador',
                state: 1
            },
            {
                id_type: 3,
                name: 'Cajer@',
                state: 1
            },
            {
                id_type: 4,
                name: 'Barbero',
                state: 1
            }
        ])

        res.status(200).json(createTypes)

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'error interno en el servidor'
        })
    }
}

const deleteAdmin = async (req, res) => {
    try{
        const {
            id_admin
        } = req.body

        const del = await Admin.destroy({
            where: {
                id_admin
            }
        })

        if(del > 0){
            res.status(200).json({
                message: 'Usuario eliminado'
            })
        }else{
            res.status(400).json({
                message: 'No es posible eliminar este usuario'
            })
        }
    }catch(error) {
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updatePasswordProfile = async (req, res) => {
    try{

        const {
            password,
            confirm_password
        } = req.body

        const token = req.headers.token

        if(password === confirm_password){

        const id_admin = jwt_decode(token).id

        const encript_password = await bcrypt.hash(password, 10)

        const response = await Admin.update(
            {
               password: encript_password
            },
            {
                where: {
                    id_admin
                }
            }
        )

        if(response > 0){
            res.status(200).json({
                message: 'Contraseña actualizada correctamente'
            })
        }else{
            res.status(400).json({
                message: 'No pudimos ejecutar su solicitud, por favor comuniquese con los administradores'
            })
        }

    }else{
        res.status(400).json({
            message: 'Las contraseñas no coinciden'
        })
    }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updateAccount = async (req, res) => {
    try{
        const {
            photo,
            name,
            last_name,
            phone
        } = req.body

        if(photo !== null &&
            name !== null &&
            last_name !== null &&
            phone !== null){

        const token = req.headers.token
        const id_admin = jwt_decode(token).id

        const response = await Admin.update(
            {
                photo,
                name,
                last_name,
                phone
            },
            {
                where: {
                    id_admin
                }
            }
        )

        if(response > 0){
            res.status(200).json({
                message: 'Perfil actualizado correctamente'
            })
        }else{
            res.status(400).json({
                message: 'No pudimos ejecutar su solicitud, por favor comuniquese con los administradores'
            })
        }

    }else{
        res.status(400).json({
            message: 'Complete los campos del formulario'
        })
    }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updateAdmin = async (req, res) => {
    try{

        const {
            id_admin,
            photo,
            name,
            last_name,
            email,
            phone,
            type_user,
            state
        } = req.body

        if(id_admin !== null &&
            photo !== null &&
            name !== null &&
            last_name !== null &&
            email !== null &&
            phone !== null &&
            type_user !== null &&
            state!== null){

                const updateAdmin = await Admin.update({
                    photo,
                    name,
                    last_name,
                    email,
                    phone,
                    type_user,
                    state
                },
                {
                    where: {
                        id_admin
                    }
                })

                if(updateAdmin > 0){
                    res.status(200).json({
                        message: 'Usuario actualizado exitosamente'
                    })
                }else{
                    res.status(400).json({
                        message: 'No es posible actualizar este usuario'
                    })
                }

        }else{
            res.status(400).json({
                message: 'Complete los campos del formulario'
            })
        }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updatePassword = async (req, res) => {
    try{

        const {
            password,
            confirm_password,
            id_admin
        } = req.body

        if(password === confirm_password){

        const encript_password = await bcrypt.hash(password, 10)

        const response = await Admin.update(
            {
               password: encript_password
            },
            {
                where: {
                    id_admin
                }
            }
        )

        if(response > 0){
            res.status(200).json({
                message: 'Contraseña actualizada correctamente'
            })
        }else{
            res.status(400).json({
                message: 'No pudimos ejecutar su solicitud, por favor comuniquese con los administradores'
            })
        }

    }else{
        res.status(400).json({
            message: 'Las contraseñas no coinciden'
        })
    }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}
 
module.exports = {
    login,
    createAdmin,
    createDefaultAdmin,
    getAdmins,
    getDatesAccount,
    example,
    getTypes,
    getBarbers,
    createDefaultTypes,
    uploadPhotoAdmin,
    updatePassword,
    updatePasswordProfile,
    deleteAdmin,
    updateAdmin,
    updateAccount
}