const WorkPermit = require('../database/models/work-permit')
const moment = require('moment-timezone')
const {Op} = require('sequelize')

const create = async (req, res) => {
  try {

    const {
      start_date, end_date, state, id_admin, observation
    } = req.body

    const create = await WorkPermit.create({
      start_date: moment(start_date).format("YYYY-MM-DD HH:mm:ss"), end_date: moment(end_date).format("YYYY-MM-DD HH:mm:ss"), observation, state, id_admin
    })
    res.status(200).json({
      message: 'Creado correctamente'
    })

  }catch(error) {
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const update = async (req, res) => {
  try{

    const {
      start_date, end_date, state, id_admin, id_work_permit, observation
    } = req.body

    const update = await WorkPermit.update({
      start_date: moment(start_date).format("YYYY-MM-DD HH:mm:ss"), end_date: moment(end_date).format("YYYY-MM-DD HH:mm:ss"), observation, state
    },{
      where: {
        id_work_permit,
        id_admin
      }
    })

    if(update > 0){
      res.status(200).json({
        message: 'Editado correctamente'
      })
    }else{
      res.status(400).json({
        message: 'Problemas al actualizar, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const getWorkPermitByAdmin = async (req, res) => {
  try{
    const {
      id_admin,
      start_date,
      end_date,
      state
    } = req.body

    let conditionTypeUser = new Object({
      id_admin
    })

    if(start_date !== null && String(start_date).trim() !== '' && end_date !== null && String(end_date).trim()){
      conditionTypeUser['start_date'] = {
          [Op.between]: [moment(start_date).format("YYYY-MM-DD HH:mm:ss"), moment(end_date).format("YYYY-MM-DD HH:mm:ss")]
      }
    }

    if(state !== null){
      conditionTypeUser['state'] = state
    }

    const result = await WorkPermit.findAll({
      where: conditionTypeUser
    })

    res.status(200).json(result)

  }catch(error) {
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const deletePermit = async (req, res) => {
  try{

    const {
      id_work_permit
    } = req.body

    const destroy = await WorkPermit.destroy({
      where: {
        id_work_permit
      }
    })

    if(destroy > 0){
      res.status(200).json({
        message: 'Eliminado correctamente'
      })
    }else{
      res.status(400).json({
        message: 'Problemas al eliminar, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

module.exports = {
  create,
  update,
  getWorkPermitByAdmin,
  deletePermit
}