const moment = require('moment-timezone')
const Admin = require('../database/models/admin')
const Service = require('../database/models/service')
const ServiceUser = require('../database/models/service-user')
const Appoiment = require('../database/models/appoiment')
const DescriptionAppoiment = require('../database/models/description-appoiment')
const WorkingTime = require('../database/models/working-time')
const WorkPermit = require('../database/models/work-permit')
const {Op} = require('sequelize')

const WebPushModel = require('../database/models/web-push')
const webpush = require('web-push')
webpush.setVapidDetails('mailto:goodcode.info@gmail.com', process.env.PUBLIC_VAPID_KEY, process.env.PRIVATE_VAPID_KEY)

//DETECT DEVICE
const DeviceDetector = require('node-device-detector')
const detector = new DeviceDetector;

//DETECT GEO IP
const GeoIP = require("simple-geoip")
const geoIP = new GeoIP(process.env.GEOIP_KEY)


const jwt_decode  = require('jwt-decode');

//MODELS
const User = require('../database/models/user');

const infoDevice = async (userAgent) => {
  const result = await detector.detect(userAgent)
  return result
}

const getBarbersInfoAppoiment = async (req, res) => {
  try{
      const {
          date,
          services
      } = req.body

      if(services.length > 0){

      let startDate = moment(date, 'YYYY-MM-DD HH:mm:ss')
      startDate.set({h: 0, m: 0, s: 0})
      const dayNumber = moment(date).day()

      let endDate = moment(date, 'YYYY-MM-DD HH:mm:ss')
      endDate.set({h: 24, m: 0, s: 0})
      
      let result = await Admin.findAll({
          attributes: ['name', 'last_name', 'photo', 'id_admin'],
          where: {
              type_user: 4,
              state: 1
          },
          include: [
              {
                  model: ServiceUser,
                  attributes: ['observation'],
                  required: false,
                  where: {
                      state: 1
                  },
                  include: [
                      {
                          model: Service,
                          attributes: ['name', 'description', 'name', 'photo', 'price', 'minutes', 'id_service'],
                          required: false,
                      }
                  ]
              },
              {
                  model: Appoiment,
                  required: false,
                  where: {
                      state: {
                        [Op.or]: [1, 2, 4]
                      },
                      date_appoiment: {
                        [Op.between]: [startDate, endDate]
                      }
                  },
                  include: [
                      {
                          model: DescriptionAppoiment,
                          required: false
                      }
                  ]
              },
              {
                  model: WorkingTime,
                  required: false,
                  where: {
                      state: 1,
                      day: dayNumber
                  }
              },
              {
                  model: WorkPermit,
                  required: false,
                  where: {
                      state: 1
                  }
              }
          ]
      })
      let barbers =  await getInfoAppoiment({services, date, barbers: result.slice()})

      res.status(200).json(barbers)

    }else{
      res.status(400).json({
        message: 'Debe seleccionar minimo un servicio'
      })
    }
  }catch(error){
      console.log(error)
      res.status(500).json({
          message: 'Error interno en el servidor'
      })
  }
}

const getMinutesService = async (services) => {

  if(services.length > 0){
    const result = await Service.findAll({
      where: {
        id_service: {
          [Op.or]: services
        }
      }
    })
    let countMinutes = 0
    for(a = 0; a < result.length; a++){
      countMinutes = countMinutes + result[a].minutes
    }
    return countMinutes
  }else{
    return 0
  }
  
}

const getInfoAppoiment = async ({services, date, barbers}) => {

  const minutesService = await getMinutesService(services)

  for(let a = 0; a < barbers.length; a++){
    let arraySections = new Array()

    const workingTimes = barbers[a].dataValues['working-times'].slice()
    const workPermits = barbers[a].dataValues['work-permits'].slice()
    const ServiceUser = barbers[a].dataValues['service-users'].slice()

    barbers[a].dataValues['free-times'] = new Array()
    barbers[a].dataValues['auth-services'] = new Array()
    barbers[a].dataValues['hours-selection'] = new Array()
    
    for (let i = 0; i < workingTimes.length; i++) {
      let appoiments = barbers[a].dataValues['appoiments'].slice().concat(workPermits)
     
      let date_start_work = moment(moment(date, 'YYYY-MM-DD').format('YYYY-MM-DD')+' '+moment(workingTimes[i].start_time, 'HH:mm:ss').format('HH:mm:ss'), 'YYYY-MM-DD HH:mm:ss')
      const date_end_work = moment(moment(date, 'YYYY-MM-DD').format('YYYY-MM-DD')+' '+moment(workingTimes[i].end_time, 'HH:mm:ss').format('HH:mm:ss'), 'YYYY-MM-DD HH:mm:ss')
      let marker = moment(date_start_work, 'YYYY-MM-DD HH:mm:ss')

      appoiments.push({
        dataValues: {
          date_appoiment: moment(moment(date, 'YYYY-MM-DD').format('YYYY-MM-DD')+' '+moment(date_end_work, 'HH:mm:ss').format('HH:mm:ss'), 'YYYY-MM-DD HH:mm:ss'),
          date_end_appoiment: moment(moment(date, 'YYYY-MM-DD').format('YYYY-MM-DD')+' '+moment(date_end_work, 'HH:mm:ss').format('HH:mm:ss'), 'YYYY-MM-DD HH:mm:ss'),
          'description-appoiments': []
        }
      })
      let countSet = 0

      while (date_start_work <= date_end_work) {
    
        for (let e = 0; e < appoiments.length; e++) {
          let dateAppoiment = null
          let dateFinishService = null
          
          if(appoiments[e].dataValues['description-appoiments']){
            dateAppoiment = moment(appoiments[e].dataValues.date_appoiment, 'YYYY-MM-DD HH:mm:ss')
            dateFinishService = moment(appoiments[e].dataValues.date_end_appoiment, 'YYYY-MM-DD HH:mm:ss')
          }else{
            dateAppoiment = moment(appoiments[e].dataValues.start_date, 'YYYY-MM-DD HH:mm:ss')
            dateFinishService = moment(appoiments[e].dataValues.end_date, 'YYYY-MM-DD HH:mm:ss')
          }

          if(dateAppoiment > date_start_work && dateFinishService > date_end_work){
            dateFinishService = moment(date_end_work, 'YYYY-MM-DD HH:mm:ss')
          }else if(dateAppoiment < date_start_work && dateFinishService < date_end_work){
            dateAppoiment = moment(date_start_work, 'YYYY-MM-DD HH:mm:ss')
          }else if(dateAppoiment < date_start_work && dateFinishService > date_end_work){
            dateAppoiment = moment(date_start_work, 'YYYY-MM-DD HH:mm:ss')
            dateFinishService = moment(dateFinishService, 'YYYY-MM-DD HH:mm:ss')
          }

          if (date_start_work >= dateAppoiment && date_start_work <= dateFinishService) {
            if (date_start_work > marker) {

              let restoreDate = date_start_work.set({m: (date_start_work.minutes() - (minutesService))})

              if( restoreDate > marker){
                arraySections.push({
                  start_date: marker.format(),
                  end_date: moment(date_start_work.set({m: (date_start_work.minutes() - (minutesService))}), 'YYYY-MM-DD HH:mm:ss').format()
                })
              }

              date_start_work = moment(dateFinishService, 'YYYY-MM-DD HH:mm:ss')
              marker = moment(dateFinishService, 'YYYY-MM-DD HH:mm:ss') 
              marker.set({s: (marker.seconds() + 1)})

            }
          }
        }

        date_start_work.set({s: (date_start_work.seconds() + 120)})

        if((date_start_work > date_end_work) && countSet === 0){
          countSet = countSet + 1
          date_start_work = appoiments[appoiments.length - 1].dataValues.date_appoiment
        }

      }
     
    }

    for(let c = 0; c < ServiceUser.length; c++){
      let filterService = services.filter((ser) => ser === ServiceUser[c].dataValues.service.id_service)
      if(filterService.length > 0) {
        barbers[a].dataValues['service-users'][c].dataValues.service.dataValues['active'] = true
      }else{
        barbers[a].dataValues['service-users'][c].dataValues.service.dataValues['active'] = false
      }
    }

    let countServices = await barbers[a].dataValues['service-users'].filter((ser) =>  ser.dataValues.service.dataValues.active === true)

    arraySections = arraySections.sort((a, b) => moment(a.start_date) - moment(b.start_date))

    barbers[a].dataValues['free-times'] = arraySections
    barbers[a].dataValues['auth-services'] = countServices.length === services.length ? true : false

  }

  let findEmpty = barbers.filter((barber) => barber.dataValues['free-times'].length === 0 || barber.dataValues['service-users'].length === 0)
  for(let e = 0; e < findEmpty.length; e++){
    let index = barbers.indexOf(findEmpty[e])
    barbers.splice(index, 1)
  }

  barbers = await barbers.sort((a, b) => ((b.dataValues['service-users'].filter((ser) =>  ser.dataValues.service.dataValues.active === true)).length) -
  ((a.dataValues['service-users'].filter((ser) =>  ser.dataValues.service.dataValues.active === true)).length ) )

  for(let a = 0; a < barbers.length; a++){
    for(let b = 0; b < barbers[a].dataValues['free-times'].length; b++){
      let start_interval = moment(barbers[a].dataValues['free-times'][b].start_date, 'YYYY-MM-DD HH:mm:ss')
      let end_interval = moment(barbers[a].dataValues['free-times'][b].end_date, 'YYYY-MM-DD HH:mm:ss')
      while(start_interval <= end_interval){
        barbers[a].dataValues['hours-selection'].push(start_interval.format())
        start_interval.set({m: start_interval.minutes() + minutesService})
      }
    }
  }

  return barbers
}

const getServices = async (req, res) => {
  try{
    const result = await Service.findAll({
      where: {
        state: 1
      }
    })

    res.status(200).json(result)
  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}



const createAppoiment = async (req, res) => {
  try{
    const {
      services,
      id_admin,
      total_price,
      date_appoiment,
      email,
      minutes,
      observation
    }  = req.body

    const token = req.headers.token
    let ip = process.env.NODE_ENV === 'production' ? req.ip : '147.75.115.226'
    ip = ip.split(':')[0]

    //GET DEVICE
    const result_device = await infoDevice(req.headers['user-agent'])

    //GET GEO_IP 
    geoIP.lookup(ip, async (err, result_geo) => {

      let date_notification = moment(date_appoiment, 'YYYY-MM-DD HH:mm:ss').set({
        m: moment(date_appoiment).minutes() - minutes,
      })

      const id_user = await jwt_decode(token).id

      let countTotalMinutes = 0
      for(let i = 0; i < services.length; i++){
        countTotalMinutes = countTotalMinutes + services[i].minutes
      }

      let date_end_appoiment = moment(date_appoiment, 'YYYY-MM-DD HH:mm:ss').set({ m: moment(date_appoiment).minutes() + countTotalMinutes })

      let appoiment = await Appoiment.create({
        id_user,
        date_appoiment: moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss'),
        date_end_appoiment: moment(date_end_appoiment).format('YYYY-MM-DD HH:mm:ss'),
        state: 1,
        id_admin_service: id_admin,
        date_notification: moment(date_notification).format('YYYY-MM-DD HH:mm:ss'),
        state_notification: 0,
        minutes_before_notification: minutes,
        service_price: total_price,
        observation_user: observation,
        ip: ip,
        device_type: result_device.device.type,
        device_brand: result_device.device.brand,
        device_model: result_device.device.model,
        client_name: result_device.client.name,
        os_name: result_device.os.name,
        os_version: result_device.os.version,
        lat: result_geo.location.lat,
        lng: result_geo.location.lng,
        region: result_geo.location.region
      })

      let arrayServices = new Array
      for(let i = 0; i < services.length; i++){
        let infoServiceUser = await ServiceUser.findOne({
          where: {
            id_service: services[i].id_service,
            id_admin
          }
        })
        
        arrayServices.push({
          id_service: services[i].id_service,
          minutes_service: services[i].minutes,
          price_service: services[i].price,
          porcentage: infoServiceUser.dataValues.porcentage,
          id_appoiment: appoiment.dataValues.id_appoiment
        })
      }

      let result_description = await DescriptionAppoiment.bulkCreate(arrayServices)

      res.status(200).json({
        message: 'Cita agendada correctamente'
      })



      //NOTIFICATIONS
      let infoAdminNotification = await Admin.findOne({
        where: id_admin
      })
      let admin = infoAdminNotification.dataValues

      let infoUserNotification = await User.findOne({
        where: id_user
      })
      let user = infoUserNotification.dataValues

      if(admin.last_ip_login !== null){
        let info_push_admin = await WebPushModel.findAll({
          where: { 
            ip: admin.last_ip_login,
            device_type: admin.device.type,
            device_brand: admin.device.brand,
            device_model: admin.device.model,
            client_name: admin.client.name,
            os_name: admin.os.name,
            os_version: admin.os.version
          }
        })
        if(info_push_admin.length > 0){
          let payload_admin = await JSON.stringify({
            title: 'Tienes una nueva cita',
            message: user.name+' '+user.last_name+' Te ha asignado una cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
            icon: process.env.URL_FRONT+'/static/social.png',
            badge: process.env.URL_FRONT+'/static/social.png',
            url: process.env.URL_FRONT,
            vibrate: [200, 100, 200] 
          })  
          await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
        }
      }

      let findAdmins = await Admin.findAll({
        where: {
          type_user: {
            [Op.or]: [1, 2, 3],
            state: 1
          }
        }
      })

      for(let i = 0; i < findAdmins.length; i++){
        let adminUser = findAdmins[i].dataValues

        if(adminUser.last_ip_login !== null){
          let info_push_admin = await WebPushModel.findAll({
            where: { 
              ip: adminUser.last_ip_login,
              device_type: adminUser.device.type,
              device_brand: adminUser.device.brand,
              device_model: adminUser.device.model,
              client_name: adminUser.client.name,
              os_name: adminUser.os.name,
              os_version: adminUser.os.version
            }
          })
          if(info_push_admin.length > 0){
            let payload_admin = await JSON.stringify({
              title: 'Cita asignada a '+admin.name+' '+admin.last_name,
              message: user.name+' '+user.last_name+' Ha creado una cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
              icon: process.env.URL_FRONT+'/static/social.png',
              badge: process.env.URL_FRONT+'/static/social.png',
              url: process.env.URL_FRONT,
              vibrate: [200, 100, 200] 
            })  
            await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
          }
        }
      }


      

    })

  }catch(error){
    console.log(error)
  }
}

const formatterDate = (date) => {
  var date = new Date(date);
  var options = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
    weekday: 'long'
  }
  return date.toLocaleTimeString("es-ES", options)
}

const getAppoimentsUser = async (req, res) => {
  try{
    const {
      state,
      start_date,
      end_date,
      id_admin_service
    } = req.body

    const token = req.headers.token
    const id_user = await jwt_decode(token).id

    let conditionAppoiment = new Object()
    conditionAppoiment['id_user'] = id_user
    if(state !== null){
      conditionAppoiment['state'] = state
    }

    if(id_admin_service !== null){
      conditionAppoiment['id_admin_service'] = id_admin_service
    }

    if(start_date !== null && String(start_date).trim() !== '' && end_date !== null && String(end_date).trim()){
      conditionAppoiment['date_appoiment'] = {
          [Op.between]: [moment(start_date).format("YYYY-MM-DD HH:mm:ss"), moment(end_date).format("YYYY-MM-DD HH:mm:ss")]
      }
    }

    const result = await Appoiment.findAll({
      where: conditionAppoiment,
      order: [
        ['date_appoiment', 'DESC'],
      ],
      include: [{
        model: DescriptionAppoiment,
        required: true,
        include: [{
          model: Service,
          required: false,
          include: [{
            model: ServiceUser,
            required: false
          }]
          
        }]
      },{
        model: Admin,
        required: false
      },{
        model: User,
        required: false
      }]
      
    })

    res.status(200).json(result)

  }catch(error){
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }

}

const getAppoimentsAdmin = async (req, res) => {
  try{
    const {
      state,
      start_date,
      end_date,
      id_admin_service
    } = req.body

    let conditionAppoiment = new Object()

    if(state !== null){
      conditionAppoiment['state'] = state
    }

    if(id_admin_service !== null){
      conditionAppoiment['id_admin_service'] = id_admin_service
    }

    if(start_date !== null && String(start_date).trim() !== '' && end_date !== null && String(end_date).trim()){
      conditionAppoiment['date_appoiment'] = {
          [Op.between]: [moment(start_date).format("YYYY-MM-DD HH:mm:ss"), moment(end_date).format("YYYY-MM-DD HH:mm:ss")]
      }
    }

    const result = await Appoiment.findAll({
      where: conditionAppoiment,
      order: [
        ['date_appoiment', 'DESC'],
      ],
      include: [{
        model: DescriptionAppoiment,
        required: true,
        include: [{
          model: Service,
          required: false,
          include: [{
            model: ServiceUser,
            required: false
          }]
          
        }]
      },{
        model: Admin,
        required: false
      },{
        model: User,
        required: false
      }]
      
    })

    res.status(200).json(result)

  }catch(error){
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }

}


const updateAppoimentAdmin = async (req, res) => {
  try{
    const {
      id_appoiment,
      state,
      money_received,
      change,
      observation_admin
    } = req.body

    let money_received_parse = parseInt(String(money_received).trim().split(".").join(""))
    let change_parse = parseInt(String(change).trim().split(".").join(""))

    console.log(id_appoiment,
      state,
      money_received,
      change)

    const token = req.headers.token

    const id_admin = await jwt_decode(token).id

    const update = await Appoiment.update({
      state,
      money_received: money_received_parse,
      change: change_parse,
      id_admin_update: id_admin,
      date_admin_update: moment().format('YYYY-MM-DD HH:mm:ss'),
      observation_admin
    },{
      where: {
        id_appoiment
      }
    })

    if(update > 0){
      res.status(200).json({
        message: 'Cita actualizada correctamente'
      })
    }else{
      res.status(400).json({
        message: 'No pudimos actualizar la cita, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}


const updateAppoimentUser = async (req, res) => {
  try{
    const {
      id_appoiment,
      observation_user
    } = req.body

    const update = await Appoiment.update({
      observation_user
    },{
      where: {
        id_appoiment
      }
    })

    if(update > 0){
      res.status(200).json({
        message: 'Observación actualizada correctamente'
      })
    }else{
      res.status(400).json({
        message: 'No pudimos actualizar la observacion, comuniquese con los administradores'
      })
    }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const cancelAppoimentUser = async (req, res) => {
  try{
    const {
      id_appoiment
    } = req.body

    const update = await Appoiment.update({
      state: 3
    },{
      where: {
        id_appoiment
      }
    })

    if(update > 0){
      res.status(200).json({
        message: 'Cita cancelada correctamente'
      })
    }else{
      res.status(400).json({
        message: 'No pudimos cancelar la cita, comuniquese con los administradores'
      })
    }


    const getInfoAppoiment = await Appoiment.findOne({
      where: {
        id_appoiment
      }
    })

    let id_admin = getInfoAppoiment.dataValues.id_admin_service
    let id_user = getInfoAppoiment.dataValues.id_user
    let date_appoiment = getInfoAppoiment.dataValues.date_appoiment


let infoAdminNotification = await Admin.findOne({
  where: id_admin
})
let admin = infoAdminNotification.dataValues

let infoUserNotification = await User.findOne({
  where: id_user
})
let user = infoUserNotification.dataValues

if(admin.last_ip_login !== null){
  let info_push_admin = await WebPushModel.findAll({
    where: { 
      ip: admin.last_ip_login,
      device_type: admin.device.type,
      device_brand: admin.device.brand,
      device_model: admin.device.model,
      client_name: admin.client.name,
      os_name: admin.os.name,
      os_version: admin.os.version
    }
  })
  if(info_push_admin.length > 0){
    let payload_admin = await JSON.stringify({
      title: '👀 CITA CANCELADA',
      message: user.name+' '+user.last_name+' cancelo cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
      icon: process.env.URL_FRONT+'/static/social.png',
      badge: process.env.URL_FRONT+'/static/social.png',
      url: process.env.URL_FRONT,
      vibrate: [200, 100, 200] 
    })  
    await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
  }
}

let findAdmins = await Admin.findAll({
  where: {
    type_user: {
      [Op.or]: [1, 2, 3],
      state: 1
    }
  }
})

for(let i = 0; i < findAdmins.length; i++){
  let adminUser = findAdmins[i].dataValues

  if(adminUser.last_ip_login !== null){
    let info_push_admin = await WebPushModel.findAll({
      where: { 
        ip: adminUser.last_ip_login,
        device_type: adminUser.device.type,
        device_brand: adminUser.device.brand,
        device_model: adminUser.device.model,
        client_name: adminUser.client.name,
        os_name: adminUser.os.name,
        os_version: adminUser.os.version
      }
    })
    if(info_push_admin.length > 0){
      let payload_admin = await JSON.stringify({
        title: '👀 HAN CANCELADO cita asignada a '+admin.name+' '+admin.last_name,
        message: user.name+' '+user.last_name+' ha cancelado una cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
        icon: process.env.URL_FRONT+'/static/social.png',
        badge: process.env.URL_FRONT+'/static/social.png',
        url: process.env.URL_FRONT,
        vibrate: [200, 100, 200] 
      })  
      await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
    }
  }
}

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const confirmAppoimentUser = async (req, res) => {
  try{
    const {
      id_appoiment
    } = req.body

    const update = await Appoiment.update({
      state: 2
    },{
      where: {
        id_appoiment
      }
    })

    if(update > 0){
      res.status(200).json({
        message: 'Cita confirmada correctamenterr'
      })
    }else{
      res.status(400).json({
        message: 'No pudimos confirmar la cita, comuniquese con los administradores'
      })
    }

    const getInfoAppoiment = await Appoiment.findOne({
      where: {
        id_appoiment
      }
    })

    let id_admin = getInfoAppoiment.dataValues.id_admin_service
    let id_user = getInfoAppoiment.dataValues.id_user
    let date_appoiment = getInfoAppoiment.dataValues.date_appoiment


let infoAdminNotification = await Admin.findOne({
  where: id_admin
})
let admin = infoAdminNotification.dataValues

let infoUserNotification = await User.findOne({
  where: id_user
})
let user = infoUserNotification.dataValues

if(admin.last_ip_login !== null){
  let info_push_admin = await WebPushModel.findAll({
    where: { 
      ip: admin.last_ip_login,
      device_type: admin.device.type,
      device_brand: admin.device.brand,
      device_model: admin.device.model,
      client_name: admin.client.name,
      os_name: admin.os.name,
      os_version: admin.os.version
    }
  })
  if(info_push_admin.length > 0){
    let payload_admin = await JSON.stringify({
      title: '😀 CITA CONFIRMADA',
      message: user.name+' '+user.last_name+' confirmo cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
      icon: process.env.URL_FRONT+'/static/social.png',
      badge: process.env.URL_FRONT+'/static/social.png',
      url: process.env.URL_FRONT,
      vibrate: [200, 100, 200] 
    })  
    await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
  }
}

let findAdmins = await Admin.findAll({
  where: {
    type_user: {
      [Op.or]: [1, 2, 3],
      state: 1
    }
  }
})

for(let i = 0; i < findAdmins.length; i++){
  let adminUser = findAdmins[i].dataValues

  if(adminUser.last_ip_login !== null){
    let info_push_admin = await WebPushModel.findAll({
      where: { 
        ip: adminUser.last_ip_login,
        device_type: adminUser.device.type,
        device_brand: adminUser.device.brand,
        device_model: adminUser.device.model,
        client_name: adminUser.client.name,
        os_name: adminUser.os.name,
        os_version: adminUser.os.version
      }
    })
    if(info_push_admin.length > 0){
      let payload_admin = await JSON.stringify({
        title: '😀 HAN CONFIRMADO cita asignada a '+admin.name+' '+admin.last_name,
        message: user.name+' '+user.last_name+' ha confirmado una cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
        icon: process.env.URL_FRONT+'/static/social.png',
        badge: process.env.URL_FRONT+'/static/social.png',
        url: process.env.URL_FRONT,
        vibrate: [200, 100, 200] 
      })  
      await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
    }
  }
}


  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}

const confirmAppoimentNotification = async (req, res) => {
  try{
    const {
      id_appoiment
    } = req.body

    const result = await Appoiment.findOne({
      where: {
        id_appoiment
      }
    })

    if(result){

    if(result.dataValues.state === 1){
      const update = await Appoiment.update({
        state: 2
      },{
        where: {
          id_appoiment
        }
      })
  
      if(update > 0){
        res.status(200).json({
          message: 'Cita confirmada correctamente'
        })
      }else{
        res.status(400).json({
          message: 'No pudimos confirmar la cita, comuniquese con los administradores'
        })
      }
    }else{
      res.status(400).json({
        message: 'Esta cita ya se encuentra confirmada'
      })
    }


    const getInfoAppoiment = await Appoiment.findOne({
      where: {
        id_appoiment
      }
    })

    let id_admin = getInfoAppoiment.dataValues.id_admin_service
    let id_user = getInfoAppoiment.dataValues.id_user
    let date_appoiment = getInfoAppoiment.dataValues.date_appoiment


let infoAdminNotification = await Admin.findOne({
  where: id_admin
})
let admin = infoAdminNotification.dataValues

let infoUserNotification = await User.findOne({
  where: id_user
})
let user = infoUserNotification.dataValues

if(admin.last_ip_login !== null){
  let info_push_admin = await WebPushModel.findAll({
    where: { 
      ip: admin.last_ip_login,
      device_type: admin.device.type,
      device_brand: admin.device.brand,
      device_model: admin.device.model,
      client_name: admin.client.name,
      os_name: admin.os.name,
      os_version: admin.os.version
    }
  })
  if(info_push_admin.length > 0){
    let payload_admin = await JSON.stringify({
      title: '😀 CITA CONFIRMADA',
      message: user.name+' '+user.last_name+' confirmo cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
      icon: process.env.URL_FRONT+'/static/social.png',
      badge: process.env.URL_FRONT+'/static/social.png',
      url: process.env.URL_FRONT,
      vibrate: [200, 100, 200] 
    })  
    await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
  }
}

let findAdmins = await Admin.findAll({
  where: {
    type_user: {
      [Op.or]: [1, 2, 3],
      state: 1
    }
  }
})

for(let i = 0; i < findAdmins.length; i++){
  let adminUser = findAdmins[i].dataValues

  if(adminUser.last_ip_login !== null){
    let info_push_admin = await WebPushModel.findAll({
      where: { 
        ip: adminUser.last_ip_login,
        device_type: adminUser.device.type,
        device_brand: adminUser.device.brand,
        device_model: adminUser.device.model,
        client_name: adminUser.client.name,
        os_name: adminUser.os.name,
        os_version: adminUser.os.version
      }
    })
    if(info_push_admin.length > 0){
      let payload_admin = await JSON.stringify({
        title: '😀 HAN CONFIRMADO cita asignada a '+admin.name+' '+admin.last_name,
        message: user.name+' '+user.last_name+' ha confirmado una cita con fecha '+formatterDate(moment(date_appoiment).format('YYYY-MM-DD HH:mm:ss')),
        icon: process.env.URL_FRONT+'/static/social.png',
        badge: process.env.URL_FRONT+'/static/social.png',
        url: process.env.URL_FRONT,
        vibrate: [200, 100, 200] 
      })  
      await webpush.sendNotification(info_push_admin[0].dataValues.subscription, payload_admin)
    }
  }
}

  }else{
    res.status(400).json({
      message: 'Solo puedes confirmar tus citas'
    })
  }

  }catch(error){
    console.log(error)
    res.status(500).json({
      message: 'Error interno en el servidor'
    })
  }
}


const getBarbers = async (req, res) => {
  try{
      const barbers = await Admin.findAll({
        attributes: ['id_admin', 'name', 'last_name'],
          where: {
              type_user: 4,
              
              state: 1
          },
      })

      res.status(200).json(barbers)
  }catch(error){
      console.log(error)
      res.status(500).json({
          message: 'Error interno en el servidor'
      })
  }
}

module.exports = {
  getBarbers,
  getBarbersInfoAppoiment,
  getServices,
  createAppoiment,
  getAppoimentsAdmin,
  getAppoimentsUser,
  updateAppoimentAdmin,
  updateAppoimentUser,
  cancelAppoimentUser,
  confirmAppoimentUser,
  confirmAppoimentNotification
}