//TOKENS SECURITY
const jwt = require('jsonwebtoken')

//NCRYPT JWT
const bcrypt = require('bcrypt')

//EMAILS
const nodemailer = require('nodemailer')
// const sgTransport = require('nodemailer-sendgrid-transport');

//RECORDS
const fs = require('fs');

//DETECT DEVICE
const DeviceDetector = require('node-device-detector')
const detector = new DeviceDetector;

//DETECT GEO IP
const GeoIP = require("simple-geoip")
const geoIP = new GeoIP(process.env.GEOIP_KEY)


const jwt_decode  = require('jwt-decode');

//MODELS
const {Op} = require('sequelize')
const User = require('../database/models/user');
const Appoiment = require('../database/models/appoiment');


const moveImage = ({ routeImage, file}) => {
  return new Promise((resolve, reject) => {
      file.mv(routeImage, err => {
          if(err) {
              reject(err)
          }else{
              resolve()
          }
      })
  })
}

const mkDir = async (dir) => {
  return new Promise((resolve, reject) => {
      let arregloCarpetas = dir.replace('.', '').split('/')
      let carpetas = './'
      for (var i=1; i < arregloCarpetas.length; i++) {
          carpetas += arregloCarpetas[i]+'/'
          if (!fs.existsSync(carpetas)){
              fs.mkdirSync(carpetas);
          }
      }
      resolve()
  })
}

const uploadImage = async ({file, dir}) =>{

  let routeImage = `${dir+file.name}`

  return mkDir(dir)
  .then(res => {
      return moveImage({file, routeImage})
  })
  .then(res => {
      return {
          routeImage: routeImage.replace('./src/public/', '/'),
          message: 'Foto subida con exito'
      }
  })
  .catch(error => {
      console.log('entro en este error')
      return {
          function: false,
          title: '😞',
          message : error
      }
  })

}

const uploadPhotoUser = async (req, res, next) => {
  
    try{
      if(req.files && !req.validateLimit){
          let file = req.files.photo

          if(file.mimetype == 'image/jpg' || file.mimetype == 'image/jpeg' || file.mimetype == 'image/png'){
              let route = `./src/public/images/profile_pictures/users/`
              uploadImage({
                  file: file,
                  dir: route
              })
              .then(msg => {
                  res.status(200).json(msg)
              })
              .catch(error => {
                  console.log(error)
                  res.status(400).json({
                    message: 'Tenemos problemas al subir el archivo, comuniquese con los administradores'
                  })
              })

          }else{
            
              res.status(400).json({
                message: 'Tenemos problemas al subir el archivo, comuniquese con los administradores'
              });
          }

      }else{
          res.status(400).json({
              message : 'La imagen supera el maximo de tamaño permitido (7mb)'
          });
      }

  }catch(error){
    console.log(error)
    res.status(500).json({
        message : String(error)
    });
  }
}

const generateCode = (min, max) => {
    return Math.floor(Math.random() * (max - min)) + min;
}

const infoDevice = async (userAgent) => {
    const result = await detector.detect(userAgent)
    return result
}

const login = async (req, res) => {
    
    try {

        const { email, password } = req.body
        let ip = process.env.NODE_ENV === 'production' ? req.ip : '147.75.115.226'
        ip = ip.split(':')[0]

        //GET DEVICE
        const result_device = await infoDevice(req.headers['user-agent'])

        //GET GEO_IP
        geoIP.lookup(ip, async (err, result_geo) => {

        let user = await User.findOne({
            where: {
                email
            }
        })
        
        if(user) {

            user = user.dataValues

            if(user.verified_account === 1){

                if(user.state === 1) {

                    const validate_password = await bcrypt.compare(password, user.password);
                    
                    if(validate_password){

                        const token = await jwt.sign({id: user.id_user}, process.env.SECRET_KEY, { expiresIn: '1d' })
                        
                        const update = await User.update({
                            last_ip_login: ip,
                            device_type: result_device.device.type,
                            device_brand: result_device.device.brand,
                            device_model: result_device.device.model,
                            client_name: result_device.client.name,
                            os_name: result_device.os.name,
                            os_version: result_device.os.version,
                            lat: result_geo.location.lat,
                            lng: result_geo.location.lng,
                            region: result_geo.location.region
                        },{
                            where: {
                                email
                            }
                        })

                        res.status(200).json({
                            message: 'Bienvenido a Barber Brothers',
                            token,
                            id_user: user.id_user,
                            email: user.email,
                            name: user.name,
                            address: user.address,
                            photo: user.photo,
                            last_name: user.last_name
                        })

                    }else{
                        res.status(400).json({
                            message: 'contraseña incorrecta'
                        })
                    }

                }else{
                    res.status(400).json({
                        message: 'El usuario se encuentra inactivo'
                    })
                }
            }else{
                res.status(400).json({
                    message: 'Es necesario validar su correo electronico, revise la bandeja de entrada'
                })
            }
        }else{
            res.status(400).json({
                message: 'El usuario no se encuentra registrado'
            })
        }

    })

    }catch(error) {
        console.log(error)
        res.status(500).json({
            message: 'error interno en el servidor'
        })
    }

}

const getUsers = async (req, res) => {
    try{
        const {
            state,
            start_date,
            end_date,
            verified_account
        } = req.body

        let conditionAdmin = new Object()

        if(state !== null){
            conditionAdmin['state'] = state
        }

        if(verified_account !== null){
            conditionAdmin['verified_account'] = verified_account
        }

        if(start_date !== null && String(start_date).trim() !== '' && end_date !== null && String(end_date).trim()){
            conditionAdmin['createdAt'] = {
                [Op.between]: [moment(start_date).format("YYYY-MM-DD HH:mm:ss"), moment(end_date).format("YYYY-MM-DD HH:mm:ss")]
            }
        }

        let admins = await User.findAll({
            where: conditionAdmin,
            include: [{
                model: Appoiment,
                required: false
            }]
        })

        res.status(200).json(admins)

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const createUser = async (req, res) => {

    try{
        const {
            name,
            last_name,
            email,
            phone,
            password,
            photo,
            confirm_password
        } = req.body

        if(name !== null &&
            last_name !== null &&
            email !== null &&
            phone !== null &&
            password !== null &&
            photo !== null &&
            String(photo).trim() !== '' &&
            confirm_password !== null){

        

        if(password === confirm_password){

            const encript_password = await bcrypt.hash(password, 10)
            const verification_code = generateCode(1000, 9999)

            const countUser = await User.count({
                where: {
                    email: email
                }
            })
            
            if(countUser > 0){
                res.status(400).json({
                    message: 'El usuario ya se encuentra registrado'
                })
            }else{
                try {

                    const user = await User.create({
                        name,
                        last_name,
                        email,
                        phone,
                        password: encript_password,
                        verification_code,
                        photo,
                        verified_account: 0,
                        state: 1
                    })

                    await sendEmail({ 
                        code: verification_code,
                        email
                    })

                    res.status(200).json({
                        message: 'Usuario creado exitosamente \n revise la bandeja de su correo electronico'
                    })

                    // res.status(201).json({
                    //     message: 'Usuario creado exitosamente'
                    // })
                    
                }catch(error){
                    console.log(error)
                    res.status(400).json({
                        message: 'El usuario ya encuentra registrado'
                    })
                }
            }

        }else{
            res.status(400).json({
                message: 'Las contraseñas no coinciden'
            })
        }

    }else{
        res.status(400).json({
            message: 'Complete los campos del formulario'
        })
    }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error en el servidor'
        })
    }

}

const verificationEmail = async (req, res) => {

    try{
        const {email, code} = req.body

        let find_user = await User.findOne({
            where: {
                email: email
            }
        })
        
        find_user = find_user.dataValues

        const verified = find_user.verified_account
        const user_code = find_user.verification_code

        if(verified === 1){
            res.status(200).json({
                message: 'Esta cuenta ya se encuentra activa'
            })
        }else if(verified === 0 || verified === null || verified === undefined){
            
            if(user_code === parseInt(code)){
                const set_verification = await User.update({
                    verified_account: 1
                },{
                    where: {
                        email
                    }
                })

                if(set_verification > 0){
                    res.status(200).json({
                        message: 'Cuenta verificada con exito'
                    })
                }else{
                    res.status(400).json({
                        message: 'Este usuario no se encuentra registrado'
                    })
                }
            }else{
                res.status(400).json({
                    message: 'El codigo enviado no pertenece a esta cuenta'
                })
            }
        }
    
    }catch(error) {
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor, comuniquese con los administradores'
        })
    }

}

const updateUser = async (req, res) => {
    try{

        const {
            id_user,
            photo,
            name,
            last_name,
            email,
            phone,
            state
        } = req.body

        if(id_user !== null &&
            photo !== null &&
            name !== null &&
            last_name !== null &&
            email !== null &&
            phone !== null &&
            state!== null){

                const updateUser = await User.update({
                    photo,
                    name,
                    last_name,
                    email,
                    phone,
                    state
                },
                {
                    where: {
                        id_user
                    }
                })

                if(updateUser > 0){
                    res.status(200).json({
                        message: 'Usuario actualizado exitosamente'
                    })
                }else{
                    res.status(400).json({
                        message: 'No es posible actualizar este usuario'
                    })
                }

        }else{
            res.status(400).json({
                message: 'Complete los campos del formulario'
            })
        }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updatePassword = async (req, res) => {
    try{

        const {
            password,
            confirm_password,
            id_user
        } = req.body

        if(password === confirm_password){

        const encript_password = await bcrypt.hash(password, 10)

        const response = await User.update(
            {
               password: encript_password
            },
            {
                where: {
                    id_user
                }
            }
        )

        if(response > 0){
            res.status(200).json({
                message: 'Contraseña actualizada correctamente'
            })
        }else{
            res.status(400).json({
                message: 'No pudimos ejecutar su solicitud, por favor comuniquese con los administradores'
            })
        }

    }else{
        res.status(400).json({
            message: 'Las contraseñas no coinciden'
        })
    }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updatePasswordProfile = async (req, res) => {
    try{

        const {
            password,
            confirm_password
        } = req.body

        const token = req.headers.token

        if(password === confirm_password){

        const id_user = jwt_decode(token).id

        const encript_password = await bcrypt.hash(password, 10)

        const response = await User.update(
            {
               password: encript_password
            },
            {
                where: {
                    id_user
                }
            }
        )

        if(response > 0){
            res.status(200).json({
                message: 'Contraseña actualizada correctamente'
            })
        }else{
            res.status(400).json({
                message: 'No pudimos ejecutar su solicitud, por favor comuniquese con los administradores'
            })
        }

    }else{
        res.status(400).json({
            message: 'Las contraseñas no coinciden'
        })
    }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const sendEmail = async ({code, email}) => {
    try {
        const transporter = await nodemailer.createTransport({
            service: 'gmail',
            port: 465,
            secure: true,
            auth: {
                type: 'login',
                user: process.env.EMAIL_SEND,
                pass: process.env.PASSWORD_EMAIL_SEND
            },
        });

        await transporter.sendMail({
        from: '"Bienvenido a Barber Brothers" <developer.marlon.torres@gmail.com>',
        to: email,
        subject: 'Verifica tu cuenta',
        html: `
        <center>
            <p style="text-align: center; margin-bottom: 40px; font-size: 20px; color: rgba(0,0,0,.5)">
                Codigo: <strong>${code}</strong>
                <br>
                De click en el siguiente enlace
            </p>
            
            <a 
            id="buttonAction" 
            style="
                background: #1976d2; 
                color: #fff; 
                padding: 10px 20px;
                font-size: 22px;
                text-decoration: none;
                border-radius: 8px;
                margin-button: 30px;
            " 
            href="${process.env.URL_FRONT}/verification-email/?email=${email}&code=${code}">
                Validar Cuenta
            </a>
        </center>
        `,
        });
    }catch(error){
        console.log(error)
    }
}

const getDatesAccount = async (req, res) => {
    try{
        const id_user = jwt_decode(req.headers.token).id

        const user = await User.findOne({
            where: {
                id_user
            },
        })

        res.status(200).json(user)
    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

const updateAccount = async (req, res) => {
    try{
        const {
            photo,
            name,
            last_name,
            phone
        } = req.body

        if(photo !== null &&
            name !== null &&
            last_name !== null &&
            phone !== null){

        const token = req.headers.token
        const id_user = jwt_decode(token).id

        const response = await User.update(
            {
                photo,
                name,
                last_name,
                phone
            },
            {
                where: {
                    id_user
                }
            }
        )

        if(response > 0){
            res.status(200).json({
                message: 'Perfil actualizado correctamente'
            })
        }else{
            res.status(400).json({
                message: 'No pudimos ejecutar su solicitud, por favor comuniquese con los administradores'
            })
        }

    }else{
        res.status(400).json({
            message: 'Complete los campos del formulario'
        })
    }

    }catch(error){
        console.log(error)
        res.status(500).json({
            message: 'Error interno en el servidor'
        })
    }
}

module.exports = {
    createUser,
    login,
    updateUser,
    updatePassword,
    verificationEmail,
    uploadPhotoUser,
    updatePasswordProfile,
    getUsers,
    getDatesAccount,
    updateAccount
}